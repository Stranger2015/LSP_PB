/**
 * Stores classes used for testing purposes: notably
 * {@link gnu.prolog.test.GoalRunner GoalRunner} which
 * can be used to load a prolog file and run a goal.
 */
package gnu.prolog.test;

