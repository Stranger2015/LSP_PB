/**
 * Classes related to the storing and creation of the database of Prolog 
 * {@link gnu.prolog.database.Predicate Predicates}
 */
package gnu.prolog.database;

