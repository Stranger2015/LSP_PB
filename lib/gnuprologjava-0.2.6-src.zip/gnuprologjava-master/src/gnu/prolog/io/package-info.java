/**
 * Classes used for IO
 */
package gnu.prolog.io;

