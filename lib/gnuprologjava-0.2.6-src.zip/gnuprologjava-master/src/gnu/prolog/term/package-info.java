/**
 * Contains the various types of {@link gnu.prolog.term.Term Term} that can be used.
 */
package gnu.prolog.term;

