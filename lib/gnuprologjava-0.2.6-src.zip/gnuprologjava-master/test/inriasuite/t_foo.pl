t_foo(1,2).
t_foo(2,3).
t_foo(3,4).
t_foo(_,_).
