%%%%%%%%%%%%%%%%%%%%%
%
%  for testing the directive include
%

include(here).
