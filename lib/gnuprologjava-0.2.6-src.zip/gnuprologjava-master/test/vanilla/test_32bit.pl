complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).
complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).
complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).
complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).
complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(a, a):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(b, b):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(c, c):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(d, d):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(e, e):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(f, f):-
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f), !,
        complex_clause(b, b) ; complex_clause(c, c) ; complex_clause(d, d) ; complex_clause(e, e) ; complex_clause(f, f).

complex_clause(g, ok):-
        log('32 bit jumps OK in retry-me-else\n').


test_32bit:-
        complex_clause(g, X),
        test_true(X == ok).