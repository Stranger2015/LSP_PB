test:-
	local_predicate.

local_predicate.